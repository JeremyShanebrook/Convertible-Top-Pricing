# Convertible Top Pricing - Desktop updater.
# Checks GitHub (JeremyShanebrook/Convertible-Top-Pricing, main branch -
# the official channel) for a newer version and updates the installed
# app safely: the current file is backed up first, and the download is
# verified as the real app file before it replaces anything.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$VersionUrl = 'https://raw.githubusercontent.com/JeremyShanebrook/Convertible-Top-Pricing/main/version.json'
$RepoBase   = 'https://raw.githubusercontent.com/JeremyShanebrook/Convertible-Top-Pricing/main/'
$AppPath    = Join-Path $env:LOCALAPPDATA 'ConvertibleTopPricing\ConvertibleTopPricing.html'

function Compare-Version($A, $B) {
  $pa = @($A -split '\.' | ForEach-Object { [int]$_ })
  $pb = @($B -split '\.' | ForEach-Object { [int]$_ })
  for ($i = 0; $i -lt 3; $i++) {
    $x = 0; $y = 0
    if ($i -lt $pa.Count) { $x = $pa[$i] }
    if ($i -lt $pb.Count) { $y = $pb[$i] }
    if ($x -gt $y) { return 1 }
    if ($x -lt $y) { return -1 }
  }
  return 0
}

try {
  if (-not (Test-Path -LiteralPath $AppPath)) {
    Write-Host 'Convertible Top Pricing does not look installed for this Windows user.'
    Write-Host 'Run Install.bat first, then run this updater again.'
    return
  }
  $localText = Get-Content -Raw -LiteralPath $AppPath
  $local = '0.0.0'
  if ($localText -match 'APP_VERSION\s*=\s*"(?<v>[0-9]+\.[0-9]+\.[0-9]+)"') { $local = $Matches.v }
  Write-Host "Installed version: $local"
  Write-Host 'Checking GitHub for a newer version...'
  $info = Invoke-RestMethod -Uri $VersionUrl -TimeoutSec 20
  $remote = [string]$info.version
  # The update payload is the desktop portable file itself, named by
  # version.json's desktop_download field - NOT the repo's index.html,
  # which is the iPhone-browser variant. The 'index.html' default keeps
  # an old version.json (without the field) downloading a working file.
  $DownloadName = 'index.html'
  if ($info.desktop_download) { $DownloadName = [string]$info.desktop_download }
  $AppUrl = $RepoBase + $DownloadName
  Write-Host "Latest version:    $remote"
  if ((Compare-Version $remote $local) -le 0) {
    Write-Host ''
    Write-Host "You're up to date - nothing to do."
    return
  }
  if ($info.app_changed -eq $false) {
    Write-Host ''
    Write-Host "Version $remote is a pricing-only update - no file download is needed."
    Write-Host 'Open Convertible Top Pricing and it applies the new prices itself'
    Write-Host '(or use Settings, then Check for updates, inside the app).'
    return
  }
  Write-Host ''
  Write-Host "Downloading the version $remote app file ($DownloadName)..."
  $tmp = Join-Path $env:TEMP ('ConvertibleTopPricing-update-' + [guid]::NewGuid().ToString('N') + '.html')
  Invoke-WebRequest -Uri $AppUrl -OutFile $tmp -UseBasicParsing -TimeoutSec 180
  $len = (Get-Item -LiteralPath $tmp).Length
  if ($len -lt 100000) { throw "The download looks incomplete ($len bytes). Your current app was not changed." }
  $head = Get-Content -Raw -LiteralPath $tmp
  if ($head -notmatch '<!doctype html' -or $head -notmatch 'Convertible Top Pricing' -or $head -notmatch 'window\.CTP') {
    throw 'The downloaded file is not the Convertible Top Pricing app. Your current app was not changed.'
  }
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $backup = "$AppPath.bak-$stamp"
  Copy-Item -LiteralPath $AppPath -Destination $backup
  Copy-Item -LiteralPath $tmp -Destination $AppPath -Force
  Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
  Write-Host ''
  Write-Host "Updated to version $remote."
  Write-Host "Your previous file was backed up as: $backup"
  Write-Host 'Close the app if it is open, then reopen Convertible Top Pricing.'
} catch {
  Write-Host ''
  Write-Host ('Update did not finish: ' + $_.Exception.Message)
  Write-Host 'Nothing was changed. Check your internet connection and run Update.bat again.'
}
