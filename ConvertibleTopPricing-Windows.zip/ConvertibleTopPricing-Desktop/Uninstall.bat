@echo off
title Uninstall Convertible Top Pricing - Desktop
echo Removing Convertible Top Pricing...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); Remove-Item (Join-Path $d 'Convertible Top Pricing.lnk') -ErrorAction SilentlyContinue; $sm=[Environment]::GetFolderPath('Programs'); Remove-Item (Join-Path $sm 'Convertible Top Pricing.lnk') -ErrorAction SilentlyContinue"
rmdir /S /Q "%LOCALAPPDATA%\ConvertibleTopPricing"
echo Done. Convertible Top Pricing was removed from this user account.
pause
