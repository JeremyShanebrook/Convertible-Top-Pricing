@echo off
setlocal
title Update Convertible Top Pricing - Desktop
set "PS1=%~dp0Update.ps1"
if not exist "%PS1%" set "PS1=%LOCALAPPDATA%\ConvertibleTopPricing\Update.ps1"
if not exist "%PS1%" (
  echo Could not find Update.ps1.
  echo Keep Update.bat and Update.ps1 together - in the extracted installer
  echo folder, or in the installed app folder - then run Update.bat again.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
echo.
pause
endlocal
