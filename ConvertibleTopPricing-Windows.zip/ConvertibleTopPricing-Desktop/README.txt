Convertible Top Pricing - Desktop
================================
Version 1.0.1

WHAT'S INSIDE
- ConvertibleTopPricing.html  The desktop app. Full catalog bundled inside:
  19,450 options - Robbins 10,648, GAHH 1,886, EZON 6,916. MSRP only.
  Tops that fit more than one car have a listing for each car they
  fit, and every listing for the same top carries the same price -
  the highest catalog price across the cars it fits.
  Robbins materials and prices come from the Robbins 2026 price
  book ONLY - never the website: every material shown for a Robbins
  part is a material the book lists for that part, at the book
  price (e.g. the 6213 Mustang front section: Sailcloth Vinyl $422,
  Stayfast Cloth $801, Sun-Fast $801, Twillfast II Cloth $1,035).
  The catalog also carries the book's other parts - side-tension
  cables, headliners, top pads, well liners, bow straps, weather
  strips, tension straps, boots, and the TN/HD/PC/GL window
  sections - for Robbins, plus headliners and boot-cover lids for
  GAHH, the same as EZON's other parts.
  Labor: the Robbins 2026 price book time for each part is the
  time used for that part from every supplier, and all materials
  of a top share that one time - they are on the same line in the
  book. GAHH/EZON times appear only where the book has no time
  for a part, as the higher of the two.
  18,256 of 19,450 options carry a labor time; the rest stay blank.
  Catalog checked Nov 16, 2026.
- ConvertibleTopPricing.ico   The app icon - the same gold-convertible
  artwork as the Android app, in 16/32/48/256 sizes. Install.bat
  copies it next to the installed app and points the Desktop and
  Start Menu shortcuts at it. To set an icon by hand instead,
  pick this file in a shortcut's Properties > Change Icon.
- Install.bat                 Windows installer (per-user, no admin needed).
- Uninstall.bat               Removes the app and its shortcuts.
- Update.bat / Update.ps1     The updater (see UPDATES below). Install.bat
  copies both next to the installed app.

INSTALL ON WINDOWS (RECOMMENDED)
1. Unzip this whole folder first (right-click the .zip > Extract All).
2. Double-click Install.bat.
3. It copies the app to your user folder and adds "Convertible Top
   Pricing" shortcuts to your Desktop and Start Menu, with the
   app icon (ConvertibleTopPricing.ico) already set on them.
4. Open it from the shortcut. It runs in your default web browser,
   fully offline. Your labor rate (Settings) is remembered on that PC.

NO-INSTALL OPTION (ANY COMPUTER)
Just double-click ConvertibleTopPricing.html. Works on Windows, Mac,
and Linux in any modern browser, with nothing to install.

USING IT
- Pick Year / Make / Model, or search by part number (SKU), material,
  or model. One card per manufacturer (Robbins / GAHH / EZON) per
  vehicle. Listings with no material recorded are not shown.
- Open a card and work down its dropdowns - part type, top style,
  window type, material, color, zipper, rain rail, drip rail, part.
  Every pick narrows the other dropdowns to combinations that
  actually exist (picking a one-piece top removes the zipper choices
  it excludes); a choice that is the only one left shows as a decided
  line instead of a dropdown. The part number, MSRP, labor, and total
  always match the full selection. Tech notes and the Robbins 2026
  catalog notes matched to that top are on the same page.
- Two-part tops (top and window sold separately): Part type on the
  card offers the top + window combo, the top only, and the window
  only, whenever the manufacturer sells them that way, so you can
  price replacing just the top or just the window. Inside a Top only
  selection, check "Add the matching window" to add the window's
  price and labor to the total.
- Where a top comes in more than one window type - heated glass,
  non-heated glass, plastic window - Window type is its own dropdown
  and filters with everything else.

- Settings: type your labor rate ($/hr). Total = MSRP + hours x rate.
  Leave it blank for parts-only totals. The Settings page also
  carries the note on how pricing and labor work, the app version,
  and a Check for updates button.

UPDATES
The catalog is baked into the file, so lookup never needs a
connection. When the computer IS online, the app checks GitHub
(JeremyShanebrook/Convertible-Top-Pricing) for a newer version each
time it opens, and from Settings > Check for updates:

- Monthly price updates apply inside the app automatically - the
  app adjusts the bundled prices and shows a notice with the new
  prices version (e.g. "Prices updated to 1.0.1 (Robbins +2.3%)").
  No download needed, and the adjusted prices are remembered on
  this computer.
- When the app itself changes, a banner offers a Download update
  button for the new app file - save it over this file (same name)
  and reopen the app. Your labor rate is kept.

Installed copies can also run Update.bat (it sits next to the
installed app, and in this folder): it checks the version on
GitHub, and when the app itself has changed it backs up the
current file, downloads the new one, verifies it is the real app
file, and only then replaces the old copy - then tells you to
reopen the app. When you are already up to date, or the update is
pricing-only (the app handles those itself), or there is no
connection, it says so and changes nothing.
