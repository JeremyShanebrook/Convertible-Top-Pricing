@echo off
setlocal
title Install Convertible Top Pricing - Desktop
echo Installing Convertible Top Pricing for this Windows user...
set "SRC=%~dp0ConvertibleTopPricing.html"
set "SRC2=%~dp0ConvertibleTopPricing-Desktop.html"
set "DEST=%LOCALAPPDATA%\ConvertibleTopPricing"
if exist "%SRC%" set "APP=%SRC%"
if not defined APP if exist "%SRC2%" set "APP=%SRC2%"
if not defined APP (
  echo.
  echo Could not find ConvertibleTopPricing.html next to this installer.
  echo Keep Install.bat and the HTML file in the same folder, then run Install.bat again.
  pause
  exit /b 1
)
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%APP%" "%DEST%\ConvertibleTopPricing.html" >nul
if exist "%~dp0ConvertibleTopPricing.ico" copy /Y "%~dp0ConvertibleTopPricing.ico" "%DEST%\ConvertibleTopPricing.ico" >nul
if exist "%~dp0Update.bat" copy /Y "%~dp0Update.bat" "%DEST%\Update.bat" >nul
if exist "%~dp0Update.ps1" copy /Y "%~dp0Update.ps1" "%DEST%\Update.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$ws.CreateShortcut((Join-Path $d 'Convertible Top Pricing.lnk')); $s.TargetPath=(Join-Path $env:LOCALAPPDATA 'ConvertibleTopPricing\ConvertibleTopPricing.html'); $s.IconLocation=(Join-Path $env:LOCALAPPDATA 'ConvertibleTopPricing\ConvertibleTopPricing.ico'); $s.Description='Convertible Top Pricing - MSRP and labor lookup'; $s.Save(); $sm=[Environment]::GetFolderPath('Programs'); $s2=$ws.CreateShortcut((Join-Path $sm 'Convertible Top Pricing.lnk')); $s2.TargetPath=(Join-Path $env:LOCALAPPDATA 'ConvertibleTopPricing\ConvertibleTopPricing.html'); $s2.IconLocation=(Join-Path $env:LOCALAPPDATA 'ConvertibleTopPricing\ConvertibleTopPricing.ico'); $s2.Description='Convertible Top Pricing - MSRP and labor lookup'; $s2.Save()"
echo.
echo Done. Shortcuts were added to your Desktop and Start Menu as "Convertible Top Pricing".
echo The app runs offline in your web browser - no account, no internet needed for lookup.
echo To update later, run Update.bat (copied next to the app) - it checks GitHub for a newer version.
choice /M "Open Convertible Top Pricing now"
if errorlevel 2 goto end
start "" "%DEST%\ConvertibleTopPricing.html"
:end
pause
endlocal
